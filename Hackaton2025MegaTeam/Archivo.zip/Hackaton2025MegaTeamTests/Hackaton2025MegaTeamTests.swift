//
//  Hackaton2025MegaTeamTests.swift
//  Hackaton2025MegaTeamTests
//
//  Created by CEDAM24 on 31/03/25.
//

import Testing
@testable import Hackaton2025MegaTeam

struct Hackaton2025MegaTeamTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
