//
//  Hackaton2025MegaTeamApp.swift
//  Hackaton2025MegaTeam
//
//  Created by CEDAM24 on 31/03/25.
//

import SwiftUI

@main
struct Hackaton2025MegaTeamApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
