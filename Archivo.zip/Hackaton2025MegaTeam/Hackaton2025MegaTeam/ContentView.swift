//
//  ContentView.swift
//  Hackaton2025MegaTeam
//
//  Created by CEDAM24 on 31/03/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Main()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
